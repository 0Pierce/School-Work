package A1;

public class DoublyLinkedList {

	
	Node header;
	Node trailer;
	
	
	
	
	public DoublyLinkedList() {
		header = new Node(-1);
		trailer = new Node(-1);
		
		header.next=trailer;
		trailer.prev = header;
		
		
	}
	
	public void addNode(int data) {
        // Add node
        Node newNode = new Node(data);
        Node lastNode = trailer.prev;

        lastNode.next = newNode;
        newNode.prev = lastNode;
        newNode.next = trailer;
        trailer.prev = newNode;
    }
	
	public void concatenate(DoublyLinkedList list2) {
		
		this.trailer.prev.next = list2.header.next;
		list2.header.next.prev = this.trailer.prev;
		
		
		this.trailer = list2.trailer;
	}
	
	public void print() {
		Node current = header.next;
		while(current != trailer) {
			System.out.println(current.data+" ");
			current = current.next;
		}
		System.out.println();
	}
	
}
